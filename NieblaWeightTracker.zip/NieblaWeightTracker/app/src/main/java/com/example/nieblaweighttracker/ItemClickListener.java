package com.example.nieblaweighttracker;

public interface ItemClickListener {
    void onDeleteClick(Integer id);
    void onEditClick(Integer id);
}
