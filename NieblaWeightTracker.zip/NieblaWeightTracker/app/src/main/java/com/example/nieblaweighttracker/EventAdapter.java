package com.example.nieblaweighttracker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;


import java.util.ArrayList;

public class EventAdapter extends ArrayAdapter<EventModel> {
    private ItemClickListener listener;
    public EventAdapter(@NonNull Context context, ArrayList<EventModel> eventModelArrayList, ItemClickListener listener){
        super(context, 0, eventModelArrayList);
        this.listener = listener;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listitemView = convertView;
        if (listitemView == null) {
            listitemView = LayoutInflater.from(getContext()).inflate(R.layout.grid_item, parent, false);
        }

        EventModel eventModel = getItem(position);
        TextView eventDate = listitemView.findViewById(R.id.eventDate);
        TextView eventWeight = listitemView.findViewById(R.id.eventWeight);
        ImageButton deleteRecord = (ImageButton) listitemView.findViewById(R.id.deleteRecord);
        ImageButton editRecord = (ImageButton) listitemView.findViewById(R.id.editRecord);

        eventDate.setText(eventModel.getEventDate().toString());
        eventWeight.setText(String.valueOf(eventModel.getEventWeight()));

        deleteRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onDeleteClick(eventModel.getId());
            }
        });

        editRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onEditClick(eventModel.getId());
            }
        });

        return listitemView;
    }
}
