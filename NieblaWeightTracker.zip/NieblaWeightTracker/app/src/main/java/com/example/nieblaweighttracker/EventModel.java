package com.example.nieblaweighttracker;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EventModel {
    private int id;
    private Date eventDate;
    private double eventWeight;
    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);

    public EventModel(int id, String inDate, double inWeight) {
        Date date = null;
        try {
            date = formatter.parse(inDate);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        this.id = id;
        this.eventDate = date;
        this.eventWeight = inWeight;
    }

    public  Date getEventDate(){
        return this.eventDate;
    }

    public  double getEventWeight(){
        return this.eventWeight;
    }
    public int getId(){ return this.id;}

}
