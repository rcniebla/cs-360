package com.example.nieblaweighttracker;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;


public class DatabaseHelper extends SQLiteOpenHelper {

    static final String DB_NAME = "WRdata3.db";
    static final int DB_VERSION =1;
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
    public static final String F_NAME = "firstname";
    public static final String L_NAME = "lastname";
    public static final String PHONE_NUMBER = "phnumber";
    public static final String GOAL_WEIGHT = "goalweight";
    public static final String ENTRY_WEIGHT = "entryweight";
    public static final String ENTRY_DATE = "entrydate";

    public DatabaseHelper(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //creating users table
        sqLiteDatabase.execSQL("create Table users(username TEXT primary key, password TEXT, firstname TEXT, lastname TEXT, phnumber TEXT)");
        //Creating Goals table
        sqLiteDatabase.execSQL("create Table goals(username TEXT primary key, goalweight REAL)");
        //Creating record table
        sqLiteDatabase.execSQL("create Table record(_id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, entrydate TEXT, entryweight REAL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop Table if exists users");
        sqLiteDatabase.execSQL("drop Table if exists goals");
        sqLiteDatabase.execSQL("drop Table if exists record");
    }
// Call to insert registrationData into users table
    public Boolean insertData(String username, String password, String firstname, String lastname, String phonenumber){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USERNAME, username);
        contentValues.put(PASSWORD, password);
        contentValues.put(F_NAME, firstname);
        contentValues.put(L_NAME, lastname);
        contentValues.put(PHONE_NUMBER, phonenumber);
        long result = database.insert("users", null, contentValues);
        if (result == -1){
            return false;   // Unable to insert
        }else {
            return true;    // Insertion complete
        }
    }

    //call to validate username exists
    public Boolean checkUsername (String username){
        SQLiteDatabase database = this.getWritableDatabase();
        //query to check if user exists in DB
        Cursor cursor = database.rawQuery("Select * from users where username = ?", new String[] {username});
        if (cursor.getCount() > 0 ){
            cursor.close();
            return true;        //user exists in DB
        } else {
            cursor.close();
            return false;       // user does not exist
        }
    }

    // validate username and password match
    public boolean checkUsernamePassword(String username, String password){
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select * from users where username = ? and password = ?", new String[] {username, password});
        if (cursor.getCount() > 0 ){
            cursor.close();
            return true;        // Username nad password match record
        } else {
            cursor.close();
            return false;       // Username and password do not match record
        }
    }

    // Get first name of user
    public String getFirstName(String username){
        String fName = "";
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select firstname from users where username =?", new String[] {username});
        if(cursor.moveToNext()){
            fName = cursor.getString(0);
        }
        cursor.close();
        return fName;
    }

    // Get user ph number
    public String getPhNum(String username){
        String phNum = "";
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select phnumber from users where username =?", new String[] {username});
        if(cursor.moveToNext()){
            phNum = cursor.getString(0);
        }
        cursor.close();
        return phNum;
    }

    // get goal weight of user
    public String getGoalWeight(String username){
        String  goalWeight = null;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select goalweight from goals where username =?", new String[] {username});
        if(cursor.moveToNext()){
            goalWeight = cursor.getString(0);
        }
        cursor.close();
        return goalWeight;
    }

    //set goal weight for user
    public Boolean insertGoal(String username, String goalweight){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USERNAME, username);
        contentValues.put(GOAL_WEIGHT, goalweight);
        long result = database.insert("goals", null, contentValues);
        if (result == -1){
            return false;   // Unable to insert
        }else {
            return true;    // Insertion complete
        }
    }

    // insert weight record
    public Boolean insertRecord(String username, String date, String weight){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USERNAME, username);
        contentValues.put(ENTRY_DATE, date);
        contentValues.put(ENTRY_WEIGHT, weight);
        long result = database.insert("record", null, contentValues);
        if (result == -1){
            return false;   // Unable to insert
        }else {
            return true;    // Insertion complete
        }
    }

    //get all weight record for user
    public Cursor getAllRecordsOfUser(String username){
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select * from record where username =?", new String[] {username});
        return cursor;
    }

    //delete record for user
    public Boolean deleteRecord(Integer id){
        SQLiteDatabase database = this.getWritableDatabase();
        return database.delete("record", "_id=? ", new String[] {id.toString()}) > 0;
    }

    // get record by provided id
    @SuppressLint("Range")
    public ArrayList getRecordById(Integer id){
        SQLiteDatabase database = this.getWritableDatabase();
        ArrayList<Object> event =new ArrayList<Object>();
        Cursor cursor = database.rawQuery("Select * from record where _id =?", new String[] {id.toString()});
        if(cursor.moveToNext()){
            event.add(cursor.getString(cursor.getColumnIndex("_id")));
            event.add(cursor.getString(cursor.getColumnIndex("entrydate")));
            event.add(cursor.getDouble(cursor.getColumnIndex("entryweight")));
        }
        cursor.close();

        return event;
    }

    // update record
    public void updateRecord(Integer id, String date, String weight){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ENTRY_DATE, date);
        contentValues.put(ENTRY_WEIGHT, weight);
        database.update("record", contentValues,"_id = ?", new String[] {id.toString()});
    }
}
