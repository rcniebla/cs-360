package com.example.nieblaweighttracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements ItemClickListener{

    TextView greeting;
    TextView goal;
    GridView eventGrid;
    DatabaseHelper DB;
    EditText weightDate;
    EditText enteredWeight;
    EditText goalWeight;
    Button submitWeight;
    Button cancel;
    Button submitGoal;

    FloatingActionButton fab;
    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    private String savedUsername = "";
    private String savedGoalWeight = "";
    private ArrayList<EventModel> eventArrayList;
    private BaseAdapter adapter;

    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //sms permission
        ActivityCompat.requestPermissions(MainActivity.this,new String[] {Manifest.permission.SEND_SMS}, 100);


        greeting = findViewById(R.id.greeting);
        goal = findViewById(R.id.goal);
        eventGrid = findViewById(R.id.eventGrid);
        fab = findViewById(R.id.fab);
        DB = new DatabaseHelper(this);

        SharedPreferences sharedpreferences = getSharedPreferences(Login.MyPREFERENCES, Context.MODE_PRIVATE);
        savedUsername = sharedpreferences.getString("usernameKey", "");
        String fName = DB.getFirstName(savedUsername);
        greeting.setText("Welcome "+ fName);

        String goalWeight = DB.getGoalWeight(savedUsername);
        if(goalWeight == null){
            enterGoalWeightDialog();
        }else {
            savedGoalWeight = DB.getGoalWeight(savedUsername);
            goal.setText("GOAL: "+savedGoalWeight);
        }

        eventArrayList = new ArrayList<EventModel>();

        loadData(eventArrayList);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                enterWeightDialog();
            }
        });
    }

    /*
    Modal that handles normal eight entry
     */
    public void enterWeightDialog(){
        dialogBuilder = new AlertDialog.Builder(this);
        final View weightEntryView = getLayoutInflater().inflate(R.layout.entry_popup, null);
        weightDate = weightEntryView.findViewById(R.id.weightDate);
        enteredWeight= weightEntryView.findViewById(R.id.enteredWeight);
        submitWeight= weightEntryView.findViewById(R.id.submitWeight);
        cancel= weightEntryView.findViewById(R.id.cancel);

        dialogBuilder.setView(weightEntryView);
        dialog = dialogBuilder.create();
        dialog.show();

        String regex = "^(?:(?:31(\\/|-|\\.)(?:0?[13578]|1[02]))\\1|(?:(?:29|30)(\\/|-|\\.)(?:0?[13-9]|1[0-2])\\2))(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$|^(?:29(\\/|-|\\.)0?2\\3(?:(?:(?:1[6-9]|[2-9]\\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\\d|2[0-8])(\\/|-|\\.)(?:(?:0?[1-9])|(?:1[0-2]))\\4(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$";
        Pattern pattern = Pattern.compile(regex);

        submitWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Matcher matcher = pattern.matcher(weightDate.getText().toString());
                if(matcher.matches() && validateWeight(enteredWeight.getText().toString())){
                    //valid date and valid weight
                    DB.insertRecord(savedUsername, weightDate.getText().toString(), enteredWeight.getText().toString());
                    Toast.makeText(MainActivity.this, "Record added successfully.", Toast.LENGTH_SHORT).show();
                    loadData(eventArrayList);
                    adapter.notifyDataSetChanged();
                    if(Integer.parseInt(enteredWeight.getText().toString()) <= Integer.parseInt(savedGoalWeight)){
                        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                            sendSMS();
                        }else{
                            Toast.makeText(MainActivity.this, "Congratulations on your achievement!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    dialog.dismiss();

                }else{
                    Toast.makeText(MainActivity.this, "Date should be dd-mm-yyyy and weight should be numerical, please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                dialog.dismiss();
            }
        });
    }

    private void sendSMS() {
        String phNum = DB.getPhNum(savedUsername);
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phNum,null,"Congratulations on hitting your goal!", null, null);
    }

    /*
    modal that handles the goal weight
     */
    public void enterGoalWeightDialog() {
        dialogBuilder = new AlertDialog.Builder(this);
        final View goalEntryView = getLayoutInflater().inflate(R.layout.goal_popup, null);
        goalWeight = goalEntryView.findViewById(R.id.goalWeight);
        submitGoal = goalEntryView.findViewById(R.id.submitGoal);

        dialogBuilder.setView(goalEntryView);
        dialog = dialogBuilder.create();
        dialog.show();

        submitGoal.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(validateWeight(goalWeight.getText().toString())) {
                    savedGoalWeight = goalWeight.getText().toString();
                    goal.setText("GOAL: " + savedGoalWeight);
                    DB.insertGoal(savedUsername, savedGoalWeight);
                    dialog.dismiss();
                }else{
                    Toast.makeText(MainActivity.this, "Weight can be numerical only, please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /*
    validating is numerical
     */
    public static boolean validateWeight(String weight){
        if(weight == null){
            return false;
        }
        try{
            double temp = Double.parseDouble(weight);
        }catch (NumberFormatException e) {
            return false;
        }
        return true;
    }

    /*
    Function that loads the existing weight entries for the user
     */
    @SuppressLint("Range")
    public void loadData(ArrayList<EventModel> myList){
        myList.clear();
        Cursor c = DB.getAllRecordsOfUser(savedUsername);

        while(c.moveToNext()) {
            myList.add(new EventModel(c.getInt(c.getColumnIndex("_id")),
                    c.getString(c.getColumnIndex("entrydate")),
                    c.getDouble(c.getColumnIndex("entryweight"))
            ));
        }

        adapter = new EventAdapter(this, myList, this);
        eventGrid.setAdapter(adapter);
    }

    /*
    Triggers deletion of record
     */
    @Override
    public void onDeleteClick(Integer id){
        if(DB.deleteRecord(id)){
            loadData(eventArrayList);
            adapter.notifyDataSetChanged();
        }else{
            Toast.makeText(MainActivity.this, "There was an issue with the request.", Toast.LENGTH_SHORT).show();
        }
    }

    /*
    Calling get Record and starting edit modal
     */
    @Override
    public void onEditClick(Integer id) {
        ArrayList event = DB.getRecordById(id);
        editWeightDialog(event);
    }

    /*
    Modal to edit currrent entry
     */
    public void editWeightDialog(ArrayList arrayList) {
        dialogBuilder = new AlertDialog.Builder(this);
        final View weightEntryView = getLayoutInflater().inflate(R.layout.entry_popup, null);
        weightDate = weightEntryView.findViewById(R.id.weightDate);
        enteredWeight = weightEntryView.findViewById(R.id.enteredWeight);
        submitWeight = weightEntryView.findViewById(R.id.submitWeight);
        cancel = weightEntryView.findViewById(R.id.cancel);

        dialogBuilder.setView(weightEntryView);
        dialog = dialogBuilder.create();
        dialog.show();

        weightDate.setText(arrayList.get(1).toString());
        enteredWeight.setText(arrayList.get(2).toString());
        String idNum = arrayList.get(0).toString();

        String regex = "^(?:(?:31(\\/|-|\\.)(?:0?[13578]|1[02]))\\1|(?:(?:29|30)(\\/|-|\\.)(?:0?[13-9]|1[0-2])\\2))(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$|^(?:29(\\/|-|\\.)0?2\\3(?:(?:(?:1[6-9]|[2-9]\\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\\d|2[0-8])(\\/|-|\\.)(?:(?:0?[1-9])|(?:1[0-2]))\\4(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$";
        Pattern pattern = Pattern.compile(regex);

        submitWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Matcher matcher = pattern.matcher(weightDate.getText().toString());
                if (matcher.matches() && validateWeight(enteredWeight.getText().toString())) {
                    //valid date and valid weight

                    DB.updateRecord(Integer.parseInt(idNum), weightDate.getText().toString(), enteredWeight.getText().toString());
                    Toast.makeText(MainActivity.this, "Record added successfully.", Toast.LENGTH_SHORT).show();
                    loadData(eventArrayList);
                    adapter.notifyDataSetChanged();
                    dialog.dismiss();
                } else {
                    Toast.makeText(MainActivity.this, "Date should be dd-mm-yyyy and weight should be numerical, please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                dialog.dismiss();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == 100 && grantResults.length > 0 && grantResults [0] == PackageManager.PERMISSION_GRANTED ){
            String phNum = DB.getPhNum(savedUsername);
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phNum,null,"You have agreed to get SMS notifications", null, null);
        }else{
            Toast.makeText(MainActivity.this, "No notifications for you.", Toast.LENGTH_SHORT).show();
        }
    }
}