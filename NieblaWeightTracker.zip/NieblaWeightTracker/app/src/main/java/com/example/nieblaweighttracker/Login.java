package com.example.nieblaweighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    public static final String MyPREFERENCES = "MyPrefs" ;
    EditText userName;
    EditText password;
    Button signIn;
    Button register;

    DatabaseHelper DB;

    SharedPreferences sharedpreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userName = findViewById(R.id.userName);
        password = findViewById(R.id.password);
        signIn = findViewById(R.id.signIn);
        register = findViewById(R.id.register);

        DB = new DatabaseHelper(this);
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        signIn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String user = userName.getText().toString();
                String pass = password.getText().toString();

                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putString("usernameKey", user);
                editor.commit();

                if(user.equals("") || pass.equals("")){
                    Toast.makeText(Login.this, "Please enter a value for all fields.", Toast.LENGTH_SHORT).show();
                }else{
                    Boolean checkUserPass = DB.checkUsernamePassword(user,pass);
                    if(checkUserPass == true){
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);  //redirect to main activity
                        startActivity(intent);
                    }else{
                        Toast.makeText(Login.this, "Credentials could not be validated, please try again.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), Registration.class);  //redirect to registration activity
                startActivity(intent);
            }
        });
    }

}