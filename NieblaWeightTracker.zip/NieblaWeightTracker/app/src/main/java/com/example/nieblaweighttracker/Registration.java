package com.example.nieblaweighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    EditText fname;
    EditText lname;
    EditText phnum;
    EditText username;
    EditText password;
    Button register;

    DatabaseHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        fname = findViewById(R.id.fNameReg);
        lname = findViewById(R.id.lNameReg);
        username = findViewById(R.id.userNameReg);
        password = findViewById(R.id.passwordReg);
        phnum = findViewById(R.id.phnum);
        register = findViewById(R.id.registerReq);

        DB = new DatabaseHelper(this);

        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String first = fname.getText().toString();
                String last = lname.getText().toString();
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String phNum = phnum.getText().toString();

                if(first.equals("") || last.equals("") || user.equals("") || pass.equals("") || phnum.equals("")){
                    Toast.makeText(Registration.this, "Please enter a value for all fields.", Toast.LENGTH_SHORT).show();
                }else{
                    Boolean checkUser = DB.checkUsername(user);
                    if(checkUser == false){
                        Boolean insert = DB.insertData(user, pass, first, last, phNum);
                        if(insert == true){
                            Toast.makeText(Registration.this, "Registered successfully.", Toast.LENGTH_SHORT).show();
                            //Redirect to login
                            Intent intent = new Intent(getApplicationContext(), Login.class);  //redirect to Login
                            startActivity(intent);
                        }else{
                            Toast.makeText(Registration.this, "Registration failed, please try again.", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(Registration.this, "Username already exists, please sign in.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}